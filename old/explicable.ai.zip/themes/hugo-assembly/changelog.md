# Changelog


## 2018-06-25

- Theme ported to Hugo with no changes made to styling/theming.
- Adjusted contact form to work with netlify
