# Hugo Themes Metadata

These images are strictly for https://themes.gohugo.io and nothing to do with the theme itself.
You can find all assets for this theme in `static/` directory.

Please refer to the root level README for directions on how to use this theme.
