#!/usr/bin/env python

from distutils.core import setup

setup(name='RuleFitCustom',
      version='0.3',
      description='RuleFit algorithm',
      author='Christoph Molnar',
      author_email='christoph.molnar@gmail.com',
      url='',
      packages=['rulefitcustom'],
     )
